# loghandler

Shortcut for setup of simultaneous stream and file handlers with custom formatting in Python logging.

```python
import loghandler

logger = loghandler.create_logger("my_logger")
logger.info("Here's a message!")
```
