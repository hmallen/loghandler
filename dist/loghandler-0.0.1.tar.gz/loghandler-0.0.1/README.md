# loghandler
Shortcut for setup of simultaneous stream and file handlers with custom formatting in Python logging
